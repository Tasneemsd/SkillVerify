const express = require("express");
const router = express.Router();
const Student = require("../models/Student"); // Make sure path is correct

// GET all students for recruiter
router.get("/students", async (req, res) => {
  try {
    const students = await Student.find(); // fetch all students from DB
    res.json({ success: true, students });
  } catch (err) {
    res.status(500).json({ success: false, message: "Failed to fetch students" });
  }
});

module.exports = router;
