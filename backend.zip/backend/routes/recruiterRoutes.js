const express = require("express");
const router = express.Router();
const Student = require("../models/Student"); // Assuming you have a Student model

// GET all students for recruiter
router.get("/students", async (req, res) => {
  try {
    const students = await Student.find(); // fetch all students
    res.json({ students });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Failed to fetch students" });
  }
});

module.exports = router;
